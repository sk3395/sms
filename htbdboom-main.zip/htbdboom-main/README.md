Disclaimer:
----------------------------------------------------
This tool is for educational purposes only ! Don't use this to take revenge
I will not be responsible for any misuse.












Tested On:
----------------------------------------------------

* Kali Linux
* Termux
* Ubuntu
* Parrot Sec OS
* Kali nethunter
* Alpine linux














Features:
----------------------------------------------------
Phone Number Sms Booming/Spam













Note:
----------------------------------------------------


This bomber only works in India !!
























---------Installation---------
-------------------------------------



$apt update

$apt upgrade

$pkg install git

$pkg install python

$git clone https://github.com/HackersTeamBangladesh/htbdboom





















Usage:
--------------------------------------------------
$ls

$cd htbdboom

$ls

$python htbdboom.py

Security Password: 19170



















Screenshots:
---------------------------------------------------

![Screenshot_2021-11-05-07-34-15-869_com termux](https://user-images.githubusercontent.com/93748209/140447957-191b2056-9c79-41cf-8bbb-691e761394ae.jpg) ![Screenshot_2021-11-05-07-34-30-067_com termux](https://user-images.githubusercontent.com/93748209/140448065-edf24f26-daf5-4c9d-b5c4-9d509565c4b9.jpg)





![Screenshot_2021-11-05-07-34-41-644_com termux](https://user-images.githubusercontent.com/93748209/140448076-3339fbc2-545f-493e-97a0-0f26f505d2b8.jpg)



![Screenshot_2021-11-05-07-36-43-417_com termux](https://user-images.githubusercontent.com/93748209/140448084-a8dcc0dd-ff12-4b63-9217-23474e2a4936.jpg)




## Telegram Channel

* `Join the Official Telegram channel of XLR8`

* `All updates of Xlr8 will be posted here !`

<a href="https://t.me/cyber_security_team1">

         Telegram

## Facebook

* Follow & Like This Page And Get Cyber Anything Help.🤭😊😊

<a href="https://www.facebook.com/CyberTeam1917/">

     Facebook Page
